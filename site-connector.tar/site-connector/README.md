# Site Connector — Apache Kafka telemetry collector

A single Go binary that runs inside a customer's network, next to their
Kafka cluster, and forwards telemetry out to a control plane. Never
accepts inbound connections — only dials out.

## What's real vs. stubbed

| Piece | Status |
|---|---|
| Repo structure, config loading | Real |
| Hub session (register/heartbeat/push) | Real protocol, HTTP+JSON stand-in for gRPC |
| Store-and-forward buffer | Real |
| Inventory reconciliation loop | Real |
| Broker/controller JMX metrics | Real — verified against a live cluster, throughput and under-replicated-partitions |
| Topic/consumer-group metadata (AdminClient) | Real — `internal/collector/admin.go`, franz-go's `kadm` package, verified against a live cluster |
| Log tailer | Real — tails `server.log` + `controller.log`, redacts password/token/secret/api_key patterns |
| Schema Registry (Karapace) metrics | Real — `internal/collector/schema_registry.go`, scrapes Karapace's native `/metrics` (no JMX — it's Python). Aggregates request counts/errors across label variants, prefers `http_requests_total` over the deprecated `karapace_http_requests_total` when both are present |
| Kafka Connect worker metrics | Real — `internal/collector/connect.go`, scrapes Connect's JMX exporter, scoped to `kafka.connect`. Worker-level only (connector/task counts, startup success/failure, rebalance state) — verified live. Per-connector/per-task metrics not yet parsed (no real connector has existed to verify the shape against) |
| mTLS, local guardrail enforcement, credential custody | Not built — deferred |
| Real gRPC (currently HTTP/JSON) | Not built |
| Docker/Helm/RPM/DEB packaging | Not built |
| Connection wizard, conformance suite | Not built |

## Quick start (all four collectors)

```bash
go get github.com/twmb/franz-go/pkg/kgo github.com/twmb/franz-go/pkg/kadm
go build -o bin/stubhub ./cmd/stubhub
go build -o bin/connector ./cmd/connector

./bin/stubhub &

SC_USE_ADMIN_COLLECTOR=1 \
SC_JMX_TARGETS="http://localhost:7071/metrics,http://localhost:7072/metrics" \
SC_SCHEMA_REGISTRY_TARGETS="http://localhost:18081/metrics" \
SC_CONNECT_JMX_TARGETS="http://localhost:7073/metrics" \
SC_KAFKA_BROKERS=localhost:9092 \
SC_SERVER_LOG=/home/apache_kafka/kafka_2.13-4.3.1/logs/server.log \
SC_CONTROLLER_LOG=/home/apache_kafka/kafka_2.13-4.3.1/logs/controller.log \
SC_COLLECT_INTERVAL=10s \
./bin/connector &

curl -s http://localhost:8081/v1/state | python3 -m json.tool
```

Check the connector's startup log for:
```
[connector] collectors active: jmx=true admin=true schema_registry=true connect=true
```

Every collector is independently opt-in — omit any `SC_*_TARGETS` var and
that collector simply doesn't run. With nothing set, the connector falls
back to a mock collector (fabricated data) so it still runs standalone
for local dev with zero setup.

## Setting up each data source

### Broker/controller JMX

Needs the Prometheus JMX Exporter javaagent attached to each JVM.

```bash
curl -L -o /home/apache_kafka/jmx_prometheus_javaagent.jar \
  https://github.com/prometheus/jmx_exporter/releases/download/1.0.1/jmx_prometheus_javaagent-1.0.1.jar

cp deploy/jmx-exporter.yml /home/apache_kafka/kafka_2.13-4.3.1/config/jmx-exporter.yml

export KAFKA_OPTS="-javaagent:/home/apache_kafka/jmx_prometheus_javaagent.jar=7071:/home/apache_kafka/kafka_2.13-4.3.1/config/jmx-exporter.yml"
bin/kafka-server-start.sh config/broker.properties
```

Repeat for the controller process on a different port (e.g. 7072) if it
runs separately. Verify: `curl http://localhost:7071/metrics` should show
`kafka_server_*` lines.

`SC_JMX_TARGETS` takes a comma-separated list — one entry per
broker/controller JMX endpoint.

### AdminClient (topics + consumer lag)

```bash
go get github.com/twmb/franz-go/pkg/kgo github.com/twmb/franz-go/pkg/kadm
go build ./...
```

If `go build` errors inside `internal/collector/admin.go`, it's likely a
`kadm` API signature mismatch against whatever version `go get` resolved
— paste the compiler error and it gets patched to match.

Set `SC_USE_ADMIN_COLLECTOR=1` and `SC_KAFKA_BROKERS` (bootstrap
address). This also enables JMX collection automatically if
`SC_JMX_TARGETS` is set.

### Schema Registry (Karapace)

```bash
SC_SCHEMA_REGISTRY_TARGETS=http://localhost:18081/metrics
```

Multiple instances (leader/replica HA): comma-separate, same pattern as
`SC_JMX_TARGETS`. Collects request counts, error counts (4xx/5xx), and
schema inventory counts (subjects, schemas, live/soft-deleted versions) —
straight from Karapace's own `/metrics`. Does NOT collect actual schema
content/versions — that needs Karapace's REST API (`GET /subjects`
etc.), which is a separate, not-yet-built piece.

### Kafka Connect worker metrics

```bash
cat > /home/apache_kafka/kafka_2.13-4.3.1/config/jmx-exporter-connect.yml << 'YAML'
lowercaseOutputName: true
rules:
  - pattern: "kafka\\.connect.*"
YAML
```

Point Connect's `KAFKA_OPTS` javaagent at this file (see
`deploy/systemd/kafka-connect.service` if you're running Connect under
systemd), then `systemctl daemon-reload && systemctl restart
kafka-connect`.

```bash
SC_CONNECT_JMX_TARGETS=http://localhost:7073/metrics
```

Multiple workers (distributed mode): comma-separate. Collects
connector/task counts, startup success/failure, and rebalance status
(epoch, currently-rebalancing, time-since-last-rebalance). Does NOT yet
collect per-connector status (running/paused/failed) or per-task
metrics — needs Connect's REST API (`GET /connectors/{name}/status`) for
status, and a real connector running to verify the per-task JMX label
shape against. Only the built-in MirrorMaker2 connectors are available
by default in a stock Kafka install — no file/JDBC/CDC plugins installed
in this environment.

### Log tailer

```bash
SC_SERVER_LOG=/home/apache_kafka/kafka_2.13-4.3.1/logs/server.log
SC_CONTROLLER_LOG=/home/apache_kafka/kafka_2.13-4.3.1/logs/controller.log
```

Tails from the point the connector starts (no backfill). Redacts
password/token/secret/api_key patterns before pushing.

## Running as systemd services (recommended)

Two unit files in `deploy/systemd/`: `site-connector-hub.service` and
`site-connector.service`. Both assume the repo lives permanently at
`/home/apache_kafka/site-connector` — adjust `WorkingDirectory`/
`ExecStart` in both if yours is elsewhere.

```bash
mkdir -p logs
cp deploy/systemd/site-connector-hub.service /etc/systemd/system/
cp deploy/systemd/site-connector.service /etc/systemd/system/
```

Edit `/etc/systemd/system/site-connector.service`'s `Environment=` lines
to match the "Quick start" env vars above (all four `SC_*_TARGETS` plus
`SC_KAFKA_BROKERS`, log paths, `SC_COLLECT_INTERVAL`). Then:

```bash
systemctl daemon-reload
systemctl enable --now site-connector-hub
systemctl enable --now site-connector

systemctl status site-connector-hub --no-pager
systemctl status site-connector --no-pager
journalctl -u site-connector -f
```

`Restart=on-failure` on both — a crash or VM reboot brings them back
automatically. After editing env vars later:

```bash
systemctl daemon-reload
systemctl restart site-connector
```

Stop everything: `systemctl stop site-connector site-connector-hub`

## Dashboard

`dashboard.html` — self-contained, no build step, polls `/v1/state`
every 3s. Serves directly off `stubhub` itself at
`http://<host>:8081/dashboard.html` (also at `/`, which redirects
there) — no separate hosting or file copying needed. If opening from a
different machine's browser than where `stubhub` runs, the Hub URL field
must point at that host's address, not `localhost`.

Built for testing/validation during development — not the real product
dashboard (a separate team is building that, closer to a proper Control
Center equivalent).

## Local dev without a real cluster

```bash
./bin/stubhub &
./bin/connector     # mock collector by default; set SC_SERVER_LOG etc. if you want log tailing too
```

## Next real steps

1. Per-connector status (`GET /connectors/{name}/status`) and per-task
   JMX metrics — needs a real connector running to verify shapes against.
2. Swap the HTTP/JSON Hub client for real gRPC streaming.
3. mTLS, local guardrail enforcement, credential custody (security —
   deferred until the rest of the pipeline is solid).
4. Docker/Helm/RPM/DEB packaging.
5. Connection wizard (Task 3) and conformance suite (Task 4/5).
6. Action execution (mutating operations) — paused pending a guardrails
   discussion; not started.
