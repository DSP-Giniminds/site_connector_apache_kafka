// cmd/connector is the Site Connector entrypoint: the single deployable
// unit that runs inside a customer's trust boundary (product doc, 5.5).
//
// Wires together: Hub session (register + heartbeat), the collector
// (metrics + AdminClient state), inventory reconciliation, and the
// store-and-forward buffer. Security-hardening pieces (mTLS, local
// guardrail enforcement, credential custody) are intentionally deferred —
// see the TODOs — per the current build sequencing.
package main

import (
	"fmt"
	"log"
	"os"
	"time"

	"site-connector/internal/buffer"
	"site-connector/internal/collector"
	"site-connector/internal/config"
	"site-connector/internal/hub"
	"site-connector/internal/inventory"
	"site-connector/internal/logshipper"
)

func main() {
	cfg := config.Load()
	connectorID := fmt.Sprintf("sc-%s-%d", cfg.TenantID, os.Getpid())

	log.Printf("[connector] starting id=%s tenant=%s hub=%s brokers=%v",
		connectorID, cfg.TenantID, cfg.HubAddress, cfg.KafkaBrokers)

	hubClient := hub.NewClient(cfg.HubAddress, connectorID)
	buf := buffer.New(cfg.BufferCapacity)
	recon := inventory.New()

	// Collector composition: each real data source is independently
	// toggled. JMX (broker/controller metrics) and AdminClient (topic/lag
	// metadata) keep their existing flags; Schema Registry collection is
	// simply on if any SC_SCHEMA_REGISTRY_TARGETS were configured — no
	// separate on/off flag needed. If nothing real is configured at all,
	// fall back to the mock so the connector still runs for local dev
	// with zero setup.
	useJMX := os.Getenv("SC_USE_REAL_COLLECTOR") == "1" || os.Getenv("SC_USE_ADMIN_COLLECTOR") == "1"
	useAdmin := os.Getenv("SC_USE_ADMIN_COLLECTOR") == "1"
	useSchemaRegistry := len(cfg.SchemaRegistryTargets) > 0
	useConnect := len(cfg.ConnectTargets) > 0

	var coll collector.Collector
	switch {
	case useJMX || useAdmin || useSchemaRegistry || useConnect:
		var jmxColl *collector.JMXHTTPCollector
		var adminColl *collector.AdminCollector
		var srColl *collector.SchemaRegistryCollector
		var connectColl *collector.ConnectCollector

		if useJMX {
			jmxColl = collector.NewJMXHTTPCollector(cfg.JMXTargets)
		}
		if useAdmin {
			var err error
			adminColl, err = collector.NewAdminCollector(cfg.KafkaBrokers)
			if err != nil {
				log.Fatalf("[connector] failed to init AdminClient collector: %v", err)
			}
			defer adminColl.Close()
		}
		if useSchemaRegistry {
			srColl = collector.NewSchemaRegistryCollector(cfg.SchemaRegistryTargets)
		}
		if useConnect {
			connectColl = collector.NewConnectCollector(cfg.ConnectTargets)
		}

		log.Printf("[connector] collectors active: jmx=%v admin=%v schema_registry=%v connect=%v",
			jmxColl != nil, adminColl != nil, srColl != nil, connectColl != nil)
		coll = collector.NewCombined(jmxColl, adminColl, srColl, connectColl)

	default:
		log.Printf("[connector] using mock collector (set SC_USE_REAL_COLLECTOR=1, SC_USE_ADMIN_COLLECTOR=1, SC_SCHEMA_REGISTRY_TARGETS, and/or SC_CONNECT_JMX_TARGETS)")
		coll = collector.NewMock(cfg.KafkaBrokers)
	}

	// Log shipping: tail each configured log file, redact, push upstream.
	// Falls back to buffering on push failure, same as metrics.
	stopTailers := make(chan struct{})
	defer close(stopTailers)
	for _, lp := range cfg.LogPaths {
		lp := lp
		go logshipper.NewTailer(lp.Path, lp.Source, 2*time.Second, func(ev logshipper.LogEvent) {
			if err := hubClient.Push("log", ev); err != nil {
				buf.Push(buffer.Event{Kind: "log", Data: ev})
			}
		}).Run(stopTailers)
	}

	// Register with the Hub. In production this retries with backoff and
	// blocks startup on failure; for local dev we log and continue so the
	// rest of the loop is still observable even if stubhub isn't up yet.
	if err := hubClient.Register(cfg.TenantID); err != nil {
		log.Printf("[connector] register failed, will keep retrying via heartbeat loop: %v", err)
	} else {
		log.Printf("[connector] registered with hub")
	}

	heartbeatTicker := time.NewTicker(cfg.HeartbeatInterval)
	collectTicker := time.NewTicker(cfg.CollectInterval)
	inventoryTicker := time.NewTicker(cfg.InventoryInterval)
	defer heartbeatTicker.Stop()
	defer collectTicker.Stop()
	defer inventoryTicker.Stop()

	for {
		select {
		case <-heartbeatTicker.C:
			if err := hubClient.Heartbeat(buf.Len(), buf.Dropped()); err != nil {
				log.Printf("[connector] heartbeat failed (buffered state preserved): %v", err)
			}

		case <-collectTicker.C:
			snap, err := coll.Collect()
			if err != nil {
				log.Printf("[connector] collect failed: %v", err)
				continue
			}
			log.Printf("[connector] collected snapshot: %d topics, %d consumer groups",
				len(snap.Topics), len(snap.ConsumerLag))

			// Try direct push; on failure, fall back to the local buffer
			// so nothing is lost across a control-plane outage.
			if err := hubClient.Push("metrics", snap); err != nil {
				buf.Push(buffer.Event{Kind: "metrics", Data: snap})
				log.Printf("[connector] push failed, buffered (depth=%d)", buf.Len())
			}

		case <-inventoryTicker.C:
			snap, err := coll.Collect()
			if err != nil {
				continue
			}
			changed := recon.Reconcile(snap)
			if changed {
				if err := hubClient.Push("inventory", snap); err != nil {
					buf.Push(buffer.Event{Kind: "inventory", Data: snap})
				}
			}
		}
	}
}
