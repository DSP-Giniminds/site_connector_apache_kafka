// cmd/stubhub is a throwaway stand-in for the control plane's Connector Hub
// service — accepts register/heartbeat/push calls, keeps the latest state
// per connector in memory, and exposes it as JSON over /v1/state so a
// dashboard can poll it. This is NOT part of the connector deliverable —
// the real Connector Hub (and its Metrics Service/Inventory Registry) live
// in the control-plane repo (section 5.3 of the doc).
package main

import (
	"encoding/json"
	"log"
	"net/http"
	"os"
	"sync"
	"time"
)

type LogLine struct {
	Source string    `json:"source"`
	Line   string    `json:"line"`
	Time   time.Time `json:"time"`
}

type ConnectorState struct {
	ConnectorID     string          `json:"connector_id"`
	TenantID        string          `json:"tenant_id"`
	Version         string          `json:"version"`
	RegisteredAt    time.Time       `json:"registered_at"`
	LastHeartbeat   time.Time       `json:"last_heartbeat"`
	BufferDepth     int             `json:"buffer_depth"`
	Dropped         int             `json:"dropped_events"`
	LastMetrics     json.RawMessage `json:"last_metrics,omitempty"`
	LastMetricsTime time.Time       `json:"last_metrics_time,omitempty"`
	LastInventory   json.RawMessage `json:"last_inventory,omitempty"`
	RecentLogs      []LogLine       `json:"recent_logs"`
}

const maxRecentLogs = 40

var (
	mu    sync.Mutex
	state = map[string]*ConnectorState{}
)

func getOrCreate(id string) *ConnectorState {
	cs, ok := state[id]
	if !ok {
		cs = &ConnectorState{ConnectorID: id}
		state[id] = cs
	}
	return cs
}

func withCORS(h http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Access-Control-Allow-Origin", "*")
		w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
		w.Header().Set("Access-Control-Allow-Headers", "Content-Type")
		if r.Method == http.MethodOptions {
			w.WriteHeader(http.StatusOK)
			return
		}
		h(w, r)
	}
}

func main() {
	mux := http.NewServeMux()

	mux.HandleFunc("/v1/register", withCORS(func(w http.ResponseWriter, r *http.Request) {
		var req map[string]any
		json.NewDecoder(r.Body).Decode(&req)
		id, _ := req["connector_id"].(string)

		mu.Lock()
		cs := getOrCreate(id)
		cs.TenantID, _ = req["tenant_id"].(string)
		cs.Version, _ = req["connector_version"].(string)
		cs.RegisteredAt = time.Now()
		mu.Unlock()

		log.Printf("[stubhub] REGISTER  connector=%v tenant=%v version=%v", id, cs.TenantID, cs.Version)
		w.WriteHeader(http.StatusOK)
	}))

	mux.HandleFunc("/v1/heartbeat", withCORS(func(w http.ResponseWriter, r *http.Request) {
		var req map[string]any
		json.NewDecoder(r.Body).Decode(&req)
		id, _ := req["connector_id"].(string)

		mu.Lock()
		cs := getOrCreate(id)
		cs.LastHeartbeat = time.Now()
		if bd, ok := req["buffer_depth"].(float64); ok {
			cs.BufferDepth = int(bd)
		}
		if dr, ok := req["dropped_events"].(float64); ok {
			cs.Dropped = int(dr)
		}
		mu.Unlock()

		log.Printf("[stubhub] HEARTBEAT connector=%v buffer_depth=%v dropped=%v", id, req["buffer_depth"], req["dropped_events"])
		w.WriteHeader(http.StatusOK)
	}))

	mux.HandleFunc("/v1/push", withCORS(func(w http.ResponseWriter, r *http.Request) {
		var req map[string]any
		json.NewDecoder(r.Body).Decode(&req)
		id, _ := req["connector_id"].(string)
		kind, _ := req["kind"].(string)
		payload, _ := json.Marshal(req["payload"])

		mu.Lock()
		cs := getOrCreate(id)
		switch kind {
		case "metrics":
			cs.LastMetrics = payload
			cs.LastMetricsTime = time.Now()
		case "inventory":
			cs.LastInventory = payload
		case "log":
			var le struct {
				Source string    `json:"Source"`
				Line   string    `json:"Line"`
				Time   time.Time `json:"Time"`
			}
			json.Unmarshal(payload, &le)
			cs.RecentLogs = append(cs.RecentLogs, LogLine{Source: le.Source, Line: le.Line, Time: le.Time})
			if len(cs.RecentLogs) > maxRecentLogs {
				cs.RecentLogs = cs.RecentLogs[len(cs.RecentLogs)-maxRecentLogs:]
			}
		}
		mu.Unlock()

		log.Printf("[stubhub] PUSH      connector=%v kind=%v", id, kind)
		w.WriteHeader(http.StatusOK)
	}))

	mux.HandleFunc("/v1/state", withCORS(func(w http.ResponseWriter, r *http.Request) {
		mu.Lock()
		out := make([]*ConnectorState, 0, len(state))
		for _, cs := range state {
			out = append(out, cs)
		}
		mu.Unlock()

		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(out)
	}))

	dashboardPath := os.Getenv("SC_DASHBOARD_PATH")
	if dashboardPath == "" {
		dashboardPath = "dashboard.html" // expects to be run from the dir containing it
	}
	mux.HandleFunc("/dashboard.html", func(w http.ResponseWriter, r *http.Request) {
		http.ServeFile(w, r, dashboardPath)
	})
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		http.Redirect(w, r, "/dashboard.html", http.StatusFound)
	})

	log.Println("[stubhub] listening on :8081 (dashboard data at /v1/state)")
	log.Println("[stubhub] dashboard served at /dashboard.html")
	log.Fatal(http.ListenAndServe(":8081", mux))
}
