module site-connector

go 1.22.2
