// Package buffer implements the connector's store-and-forward layer.
//
// Purpose (per the product doc, section 5.5): a bounded local buffer so that
// a control-plane outage does not lose telemetry. Default target is 24h of
// retention; here it's a capacity-bounded ring so memory stays predictable.
package buffer

import "sync"

// Event is a generic envelope for anything queued for delivery to the Hub
// (metrics batches, inventory snapshots, heartbeats-with-payload, etc).
type Event struct {
	Kind string // "metrics" | "inventory" | ...
	Data any
}

type RingBuffer struct {
	mu       sync.Mutex
	items    []Event
	capacity int
	dropped  int // count of events evicted due to capacity — surfaced as a health signal
}

func New(capacity int) *RingBuffer {
	return &RingBuffer{
		items:    make([]Event, 0, capacity),
		capacity: capacity,
	}
}

// Push adds an event, evicting the oldest if at capacity.
func (b *RingBuffer) Push(e Event) {
	b.mu.Lock()
	defer b.mu.Unlock()
	if len(b.items) >= b.capacity {
		b.items = b.items[1:]
		b.dropped++
	}
	b.items = append(b.items, e)
}

// Drain removes and returns everything currently buffered — used when
// a Hub connection is (re)established and it's time to flush.
func (b *RingBuffer) Drain() []Event {
	b.mu.Lock()
	defer b.mu.Unlock()
	out := b.items
	b.items = make([]Event, 0, b.capacity)
	return out
}

func (b *RingBuffer) Len() int {
	b.mu.Lock()
	defer b.mu.Unlock()
	return len(b.items)
}

func (b *RingBuffer) Dropped() int {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.dropped
}
