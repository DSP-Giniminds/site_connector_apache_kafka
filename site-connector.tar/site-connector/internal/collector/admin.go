// Real AdminClient-backed collector: topic metadata (partitions, RF,
// configs) and consumer group lag, via franz-go's kadm package. This is
// the piece JMX cannot provide (JMX only gives rates/gauges, not cluster
// metadata) — it's what fills in the Topics/ConsumerLag fields that the
// JMX-HTTP collector leaves empty.
//
// BUILD NOTE: this file was written without the ability to compile it in
// the authoring sandbox (no Go module proxy access there). The shape of
// the kadm API below reflects franz-go's documented interface, but exact
// method names can shift between versions — if `go build` errors out on
// this file, paste the error back and it'll get fixed against the actual
// version `go get` resolved.
//
// Setup on a machine with module proxy access:
//   go get github.com/twmb/franz-go/pkg/kgo github.com/twmb/franz-go/pkg/kadm
package collector

import (
	"context"
	"fmt"
	"time"

	"github.com/twmb/franz-go/pkg/kadm"
	"github.com/twmb/franz-go/pkg/kgo"
)

type AdminCollector struct {
	brokers []string
	cl      *kgo.Client
	adm     *kadm.Client
}

// NewAdminCollector opens a persistent client against the given bootstrap
// brokers. Call Close() when done (e.g. on connector shutdown).
func NewAdminCollector(brokers []string) (*AdminCollector, error) {
	cl, err := kgo.NewClient(kgo.SeedBrokers(brokers...))
	if err != nil {
		return nil, fmt.Errorf("kgo client init: %w", err)
	}
	return &AdminCollector{
		brokers: brokers,
		cl:      cl,
		adm:     kadm.NewClient(cl),
	}, nil
}

func (a *AdminCollector) Close() {
	a.cl.Close()
}

func (a *AdminCollector) Collect() (Snapshot, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	snap := Snapshot{Timestamp: time.Now()}

	// --- Topic metadata ---
	topicDetails, err := a.adm.ListTopics(ctx)
	if err != nil {
		return snap, fmt.Errorf("list topics: %w", err)
	}
	for name, td := range topicDetails {
		if td.Err != nil {
			continue // skip topics that errored on describe (e.g. auth)
		}
		rf := 0
		if len(td.Partitions) > 0 {
			for _, p := range td.Partitions {
				rf = len(p.Replicas)
				break // assume uniform RF across partitions for this pass
			}
		}
		snap.Topics = append(snap.Topics, Topic{
			Name:       name,
			Partitions: len(td.Partitions),
			RF:         rf,
			Configs:    map[string]string{}, // TODO: adm.DescribeTopicConfigs for retention.ms etc if needed
		})
	}

	// --- Consumer group lag ---
	groups, err := a.adm.ListGroups(ctx)
	if err != nil {
		return snap, fmt.Errorf("list groups: %w", err)
	}
	groupNames := make([]string, 0, len(groups))
	for name := range groups {
		groupNames = append(groupNames, name)
	}
	if len(groupNames) > 0 {
		lags, err := a.adm.Lag(ctx, groupNames...)
		if err != nil {
			return snap, fmt.Errorf("describe lag: %w", err)
		}
		for group, l := range lags {
			var total int64
			for _, tl := range l.Lag {
				for _, pl := range tl {
					if pl.Lag > 0 {
						total += pl.Lag
					}
				}
			}
			snap.ConsumerLag = append(snap.ConsumerLag, ConsumerGroupLag{
				GroupID: group,
				Lag:     total,
			})
		}
	}

	return snap, nil
}
