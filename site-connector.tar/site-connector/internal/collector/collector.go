// Package collector pulls broker metrics and AdminClient-derived cluster
// state from Apache Kafka (topics, partitions, ISR, consumer group lag).
//
// NOTE ON THIS SANDBOX BUILD: a real implementation needs a Kafka client
// library (e.g. twmb/franz-go or confluentinc/confluent-kafka-go) to talk
// AdminClient protocol to real brokers, plus JMX scraping for broker
// metrics. This sandbox has no access to the Go module proxy and no Docker,
// so there's no way to fetch that dependency or run a real broker here.
//
// What's below is a Collector interface (the real contract) plus a
// MockCollector that fabricates plausible data, so the rest of the
// connector — buffering, the Hub client, the reconciliation loop — can be
// built and exercised end to end. Swapping MockCollector for a real
// franz-go-backed implementation later should not require touching any
// other package.
package collector

import (
	"math/rand"
	"time"
)

type Topic struct {
	Name       string
	Partitions int
	RF         int
	Configs    map[string]string
}

type ConsumerGroupLag struct {
	GroupID string
	Lag     int64
}

type BrokerMetrics struct {
	Source          string // which JMX target this came from, e.g. "http://localhost:7071/metrics"
	Role            string // "broker" | "controller" — inferred from ActiveControllerCount presence
	BrokerID        int
	BytesInPerSec   float64
	BytesOutPerSec  float64
	UnderReplicated int
}

// Snapshot is one pull's worth of cluster state.
type Snapshot struct {
	Timestamp             time.Time
	Topics                []Topic
	ConsumerLag           []ConsumerGroupLag
	BrokerMetrics         []BrokerMetrics
	SchemaRegistryMetrics []SchemaRegistryMetrics
	ConnectMetrics        []ConnectWorkerMetrics
}

// Collector is the contract every distribution-specific implementation
// fulfils. For Apache-only scope right now there's just one implementation
// to build for real; MSK/Strimzi/Confluent adapters would each get their
// own Collector behind the same interface.
type Collector interface {
	Collect() (Snapshot, error)
}

// MockCollector fabricates a snapshot so the pipeline can be exercised
// without a real broker. Replace with a franz-go AdminClient-backed
// implementation once module/network access is available.
type MockCollector struct {
	Brokers []string
}

func NewMock(brokers []string) *MockCollector {
	return &MockCollector{Brokers: brokers}
}

func (m *MockCollector) Collect() (Snapshot, error) {
	return Snapshot{
		Timestamp: time.Now(),
		Topics: []Topic{
			{Name: "orders.events", Partitions: 12, RF: 3, Configs: map[string]string{"retention.ms": "604800000"}},
			{Name: "payments.audit", Partitions: 6, RF: 3, Configs: map[string]string{"retention.ms": "2592000000"}},
		},
		ConsumerLag: []ConsumerGroupLag{
			{GroupID: "orders-consumer", Lag: int64(rand.Intn(500))},
			{GroupID: "fraud-detector", Lag: int64(rand.Intn(50))},
		},
		BrokerMetrics: []BrokerMetrics{
			{BrokerID: 1, BytesInPerSec: 1200000 + rand.Float64()*50000, BytesOutPerSec: 900000, UnderReplicated: 0},
		},
	}, nil
}
