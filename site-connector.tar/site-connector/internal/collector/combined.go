// CombinedCollector merges output from any subset of: JMX metrics
// (broker/controller), AdminClient metadata (topics/consumer lag),
// Schema Registry metrics, and Connect worker metrics — into a single
// Snapshot, since main.go depends on one Collector. Each piece is
// optional (nil-safe).
package collector

import "time"

type CombinedCollector struct {
	jmx            *JMXHTTPCollector
	admin          *AdminCollector
	schemaRegistry *SchemaRegistryCollector
	connect        *ConnectCollector
}

func NewCombined(jmx *JMXHTTPCollector, admin *AdminCollector, schemaRegistry *SchemaRegistryCollector, connect *ConnectCollector) *CombinedCollector {
	return &CombinedCollector{jmx: jmx, admin: admin, schemaRegistry: schemaRegistry, connect: connect}
}

func (c *CombinedCollector) Collect() (Snapshot, error) {
	var result Snapshot
	result.Timestamp = time.Now()

	if c.jmx != nil {
		snap, err := c.jmx.Collect()
		if err != nil {
			return result, err
		}
		result.BrokerMetrics = snap.BrokerMetrics
	}

	if c.admin != nil {
		snap, err := c.admin.Collect()
		if err != nil {
			return result, err
		}
		result.Topics = snap.Topics
		result.ConsumerLag = snap.ConsumerLag
	}

	if c.schemaRegistry != nil {
		snap, err := c.schemaRegistry.Collect()
		if err != nil {
			return result, err
		}
		result.SchemaRegistryMetrics = snap.SchemaRegistryMetrics
	}

	if c.connect != nil {
		snap, err := c.connect.Collect()
		if err != nil {
			return result, err
		}
		result.ConnectMetrics = snap.ConnectMetrics
	}

	return result, nil
}
