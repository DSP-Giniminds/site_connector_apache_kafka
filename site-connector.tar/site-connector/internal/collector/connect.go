// Real metrics collection from the Kafka Connect worker's JMX Exporter
// endpoint (see deploy/jmx-exporter-connect.yml — scoped to the
// kafka.connect domain, default auto-naming). Metric names below are
// copied verbatim from a real running Connect 4.3.1 worker, not guessed.
//
// Worker-level only for now: connector/task counts, startup success/
// failure, and rebalance state. Per-connector and per-task metrics
// (kafka.connect:type=connector-metrics/task-metrics, labeled by
// connector= and task=) are NOT yet parsed here — the exporter config
// already scopes broadly enough to pick them up once a real connector
// exists, but this collector doesn't read them yet since there's been
// no real connector running to verify the exact label/attribute shape
// against. Add a second pass here once one exists — same
// scrapePrometheus() plumbing, just a new set of firstValue/label logic.
package collector

import (
	"fmt"
	"net/http"
	"time"
)

type ConnectWorkerMetrics struct {
	Source string // the target URL this came from

	ConnectorCount int
	TaskCount      int

	ConnectorStartupAttempts int64
	ConnectorStartupFailures int64
	ConnectorStartupSuccess  int64

	TaskStartupAttempts int64
	TaskStartupFailures int64
	TaskStartupSuccess  int64

	Rebalancing              bool
	Epoch                    int64
	CompletedRebalances      int64
	TimeSinceLastRebalanceMs int64
}

type ConnectCollector struct {
	Targets []string
	client  *http.Client
}

func NewConnectCollector(targets []string) *ConnectCollector {
	return &ConnectCollector{
		Targets: targets,
		client:  newHTTPClient(),
	}
}

func (c *ConnectCollector) Collect() (Snapshot, error) {
	snap := Snapshot{Timestamp: time.Now()}

	for _, target := range c.Targets {
		series, err := scrapePrometheus(c.client, target)
		if err != nil {
			return snap, fmt.Errorf("scrape %s: %w", target, err)
		}

		m := ConnectWorkerMetrics{Source: target}

		if v, ok := firstValue(series, "kafka_connect_connect_worker_metrics_connector_count"); ok {
			m.ConnectorCount = int(v)
		}
		if v, ok := firstValue(series, "kafka_connect_connect_worker_metrics_task_count"); ok {
			m.TaskCount = int(v)
		}
		if v, ok := firstValue(series, "kafka_connect_connect_worker_metrics_connector_startup_attempts"); ok {
			m.ConnectorStartupAttempts = int64(v)
		}
		if v, ok := firstValue(series, "kafka_connect_connect_worker_metrics_connector_startup_failure"); ok {
			m.ConnectorStartupFailures = int64(v)
		}
		if v, ok := firstValue(series, "kafka_connect_connect_worker_metrics_connector_startup_success"); ok {
			m.ConnectorStartupSuccess = int64(v)
		}
		if v, ok := firstValue(series, "kafka_connect_connect_worker_metrics_task_startup_attempts"); ok {
			m.TaskStartupAttempts = int64(v)
		}
		if v, ok := firstValue(series, "kafka_connect_connect_worker_metrics_task_startup_failure"); ok {
			m.TaskStartupFailures = int64(v)
		}
		if v, ok := firstValue(series, "kafka_connect_connect_worker_metrics_task_startup_success"); ok {
			m.TaskStartupSuccess = int64(v)
		}
		if v, ok := firstValue(series, "kafka_connect_connect_worker_rebalance_metrics_rebalancing"); ok {
			m.Rebalancing = v != 0
		}
		if v, ok := firstValue(series, "kafka_connect_connect_worker_rebalance_metrics_epoch"); ok {
			m.Epoch = int64(v)
		}
		if v, ok := firstValue(series, "kafka_connect_connect_worker_rebalance_metrics_completed_rebalances"); ok {
			m.CompletedRebalances = int64(v)
		}
		if v, ok := firstValue(series, "kafka_connect_connect_worker_rebalance_metrics_time_since_last_rebalance_ms"); ok {
			m.TimeSinceLastRebalanceMs = int64(v)
		}

		snap.ConnectMetrics = append(snap.ConnectMetrics, m)
	}

	return snap, nil
}
