// Real metrics collection, sourced from the Prometheus JMX Exporter
// javaagent running inside the Kafka broker/controller JVMs (see
// deploy/jmx-exporter.yml). This avoids needing a JMX/RMI client library
// in Go — the exporter already speaks plain HTTP + Prometheus text format,
// parsed by the shared scrapePrometheus() in promscrape.go.
package collector

import (
	"fmt"
	"net/http"
	"time"
)

// JMXHTTPCollector scrapes one or more JMX-exporter endpoints (one per
// broker/controller process) and folds the results into a Snapshot.
type JMXHTTPCollector struct {
	Targets []string // e.g. []string{"http://10.0.1.5:7071/metrics"}
	client  *http.Client
}

func NewJMXHTTPCollector(targets []string) *JMXHTTPCollector {
	return &JMXHTTPCollector{
		Targets: targets,
		client:  newHTTPClient(),
	}
}

func (j *JMXHTTPCollector) Collect() (Snapshot, error) {
	snap := Snapshot{Timestamp: time.Now()}

	for _, target := range j.Targets {
		series, err := scrapePrometheus(j.client, target)
		if err != nil {
			return snap, fmt.Errorf("scrape %s: %w", target, err)
		}

		role := "broker"
		if hasSeries(series, "kafka_controller_active_controller_count") {
			role = "controller"
		}
		bytesIn, _ := firstValue(series, "kafka_server_brokertopicmetrics_bytesinpersec_per_sec")
		bytesOut, _ := firstValue(series, "kafka_server_brokertopicmetrics_bytesoutpersec_per_sec")
		underRep, _ := firstValue(series, "kafka_server_replicamanager_under_replicated_partitions")

		snap.BrokerMetrics = append(snap.BrokerMetrics, BrokerMetrics{
			Source:          target,
			Role:            role,
			BytesInPerSec:   bytesIn,
			BytesOutPerSec:  bytesOut,
			UnderReplicated: int(underRep),
		})
	}

	// NOTE: topic/config inventory and consumer-group lag still need the
	// AdminClient side (franz-go), not JMX — JMX only gives you rates and
	// gauges, not cluster metadata. Combine with AdminCollector via
	// CombinedCollector for both in one Snapshot.
	return snap, nil
}
