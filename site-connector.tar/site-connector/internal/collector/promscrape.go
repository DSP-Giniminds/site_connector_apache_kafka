// Shared Prometheus text-format scraping, used by any collector that
// talks to an HTTP endpoint exposing Prometheus-format metrics — the JMX
// Exporter (broker/controller) and Karapace's native /metrics endpoint
// both qualify, even though the data they carry means very different
// things.
//
// Unlike a first-draft flat name->value map, this preserves labels —
// required for metrics like Karapace's karapace_http_requests_total,
// which repeats the same metric name once per (method, path, status)
// combination. A caller that ignores labels (like the JMX collector,
// where the metrics it reads happen to be single-valued gauges) can just
// take the first matching series; a caller that needs to aggregate across
// label variants (like summing Schema Registry request counts) has what
// it needs to do that correctly instead of silently keeping only the
// last line seen.
package collector

import (
	"bufio"
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"time"
)

type promSeries struct {
	Name   string
	Labels map[string]string
	Value  float64
}

func newHTTPClient() *http.Client {
	return &http.Client{Timeout: 5 * time.Second}
}

// scrapePrometheus fetches and parses Prometheus text-format metrics from
// a single endpoint into a slice of labeled series (order preserved,
// duplicates by name+label combo kept as separate entries — aggregation
// is the caller's job, not the parser's).
func scrapePrometheus(client *http.Client, url string) ([]promSeries, error) {
	resp, err := client.Get(url)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 300 {
		return nil, fmt.Errorf("unexpected status %d", resp.StatusCode)
	}

	var out []promSeries
	scanner := bufio.NewScanner(resp.Body)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue // comments / HELP / TYPE lines
		}

		fields := strings.Fields(line)
		if len(fields) < 2 {
			continue
		}
		val, err := strconv.ParseFloat(fields[len(fields)-1], 64)
		if err != nil {
			continue
		}

		namePart := fields[0]
		name := namePart
		labels := map[string]string{}
		if brace := strings.IndexByte(namePart, '{'); brace >= 0 {
			name = namePart[:brace]
			labelStr := strings.TrimSuffix(namePart[brace+1:], "}")
			labels = parseLabels(labelStr)
		}

		out = append(out, promSeries{Name: name, Labels: labels, Value: val})
	}
	return out, scanner.Err()
}

// parseLabels splits a Prometheus label string like
// `method="GET",path="/subjects",status="200"` into a map. Deliberately
// simple (no support for escaped quotes/commas inside label values) —
// sufficient for the metrics this connector actually reads; revisit if a
// source ever needs more.
func parseLabels(s string) map[string]string {
	out := map[string]string{}
	if s == "" {
		return out
	}
	for _, pair := range strings.Split(s, ",") {
		kv := strings.SplitN(pair, "=", 2)
		if len(kv) != 2 {
			continue
		}
		key := strings.TrimSpace(kv[0])
		val := strings.Trim(strings.TrimSpace(kv[1]), `"`)
		out[key] = val
	}
	return out
}

// firstValue returns the value of the first series matching name,
// ignoring labels — for metrics known to be single-valued (gauges like
// under-replicated-partitions or schema-count that don't vary by label).
func firstValue(series []promSeries, name string) (float64, bool) {
	for _, s := range series {
		if s.Name == name {
			return s.Value, true
		}
	}
	return 0, false
}

// hasSeries reports whether any series with this name exists at all —
// useful for role detection (e.g. "does this JMX target expose
// kafka_controller_* metrics, meaning it's a controller process").
func hasSeries(series []promSeries, name string) bool {
	_, ok := firstValue(series, name)
	return ok
}
