// Real metrics collection from Karapace's own native Prometheus endpoint
// (confirmed live at http://<host>:18081/metrics on the target VM — no
// JMX exporter needed here, Karapace is a Python service that already
// speaks Prometheus text format directly).
//
// Unlike the JMX collector's metrics (single-valued gauges), Karapace's
// request-count metric repeats the same name once per (method, path,
// status) label combination — so this collector aggregates across label
// variants rather than taking a single value, using the shared
// label-aware scrapePrometheus() parser.
package collector

import (
	"fmt"
	"net/http"
	"strconv"
	"time"
)

type SchemaRegistryMetrics struct {
	Source              string // the target URL this came from
	TotalRequests       int64  // sum across all method/path/status label combos
	ErrorRequests       int64  // subset with status >= 400
	Subjects            int    // karapace_schema_reader_subjects
	Schemas             int    // karapace_schema_reader_schemas
	LiveVersions        int    // karapace_schema_reader_subject_data_schema_versions{state="live"}
	SoftDeletedVersions int    // ...{state="soft_deleted"}
}

type SchemaRegistryCollector struct {
	Targets []string
	client  *http.Client
}

func NewSchemaRegistryCollector(targets []string) *SchemaRegistryCollector {
	return &SchemaRegistryCollector{
		Targets: targets,
		client:  newHTTPClient(),
	}
}

func (s *SchemaRegistryCollector) Collect() (Snapshot, error) {
	snap := Snapshot{Timestamp: time.Now()}

	for _, target := range s.Targets {
		series, err := scrapePrometheus(s.client, target)
		if err != nil {
			return snap, fmt.Errorf("scrape %s: %w", target, err)
		}

		m := SchemaRegistryMetrics{Source: target}

		// Prefer the non-deprecated metric name if this Karapace version
		// exposes it; karapace_http_requests_total's own HELP text says
		// "Deprecated: use http_requests_total" as of the version tested
		// against. Fall back to the karapace-prefixed one for older
		// versions that don't have the replacement yet.
		requestMetricName := "http_requests_total"
		if !hasSeries(series, requestMetricName) {
			requestMetricName = "karapace_http_requests_total"
		}
		for _, sr := range series {
			if sr.Name != requestMetricName {
				continue
			}
			m.TotalRequests += int64(sr.Value)
			if status, err := strconv.Atoi(sr.Labels["status"]); err == nil && status >= 400 {
				m.ErrorRequests += int64(sr.Value)
			}
		}

		if v, ok := firstValue(series, "karapace_schema_reader_subjects"); ok {
			m.Subjects = int(v)
		}
		if v, ok := firstValue(series, "karapace_schema_reader_schemas"); ok {
			m.Schemas = int(v)
		}
		for _, sr := range series {
			if sr.Name != "karapace_schema_reader_subject_data_schema_versions" {
				continue
			}
			switch sr.Labels["state"] {
			case "live":
				m.LiveVersions = int(sr.Value)
			case "soft_deleted":
				m.SoftDeletedVersions = int(sr.Value)
			}
		}

		snap.SchemaRegistryMetrics = append(snap.SchemaRegistryMetrics, m)
	}

	return snap, nil
}
