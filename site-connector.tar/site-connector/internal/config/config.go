// Package config loads Site Connector runtime configuration.
//
// Real deployment: values come from a mounted Helm-managed ConfigMap/Secret.
// For now: env vars with sane local-dev defaults.
package config

import (
	"os"
	"strings"
	"time"
)

type Config struct {
	TenantID          string        // which customer/tenant this connector belongs to
	HubAddress        string        // control-plane Connector Hub endpoint (host:port)
	HeartbeatInterval time.Duration // how often to ping the Hub
	CollectInterval   time.Duration // how often to scrape metrics/state
	InventoryInterval time.Duration // how often to run full inventory reconciliation
	BufferCapacity    int           // max buffered events before oldest are dropped
	KafkaBrokers      []string      // bootstrap brokers for the Apache Kafka cluster
	JMXTargets        []string      // JMX exporter HTTP endpoints, one per broker/controller
	SchemaRegistryTargets []string  // Karapace /metrics endpoints, one per instance
	ConnectTargets    []string      // Connect worker JMX exporter endpoints, one per worker
	LogPaths          []LogPath     // Kafka log files to tail
}

type LogPath struct {
	Path   string // filesystem path
	Source string // label used when shipping ("server.log", "controller.log")
}

func Load() Config {
	return Config{
		TenantID:          getEnv("SC_TENANT_ID", "local-dev-tenant"),
		HubAddress:        getEnv("SC_HUB_ADDRESS", "localhost:8081"),
		HeartbeatInterval: getDuration("SC_HEARTBEAT_INTERVAL", 5*time.Second),
		CollectInterval:   getDuration("SC_COLLECT_INTERVAL", 15*time.Second),
		InventoryInterval: getDuration("SC_INVENTORY_INTERVAL", 60*time.Second),
		BufferCapacity:    500,
		KafkaBrokers:      []string{getEnv("SC_KAFKA_BROKERS", "localhost:9092")},
		// SC_JMX_TARGETS: comma-separated list, e.g.
		// "http://localhost:7071/metrics,http://localhost:7072/metrics"
		// (broker + controller). SC_JMX_TARGET (singular) still works for
		// a single-target setup.
		JMXTargets: getJMXTargets(),
		// SC_SCHEMA_REGISTRY_TARGETS: comma-separated, e.g.
		// "http://localhost:18081/metrics". Empty by default — Schema
		// Registry collection is opt-in since not everyone runs Karapace.
		SchemaRegistryTargets: getCommaList("SC_SCHEMA_REGISTRY_TARGETS"),
		// SC_CONNECT_JMX_TARGETS: comma-separated, e.g.
		// "http://localhost:7073/metrics". Empty by default — opt-in,
		// same pattern as Schema Registry.
		ConnectTargets: getCommaList("SC_CONNECT_JMX_TARGETS"),
		LogPaths: []LogPath{
			{Path: getEnv("SC_SERVER_LOG", "/home/apache_kafka/kafka_2.13-4.3.1/logs/server.log"), Source: "server.log"},
			{Path: getEnv("SC_CONTROLLER_LOG", "/home/apache_kafka/kafka_2.13-4.3.1/logs/controller.log"), Source: "controller.log"},
		},
	}
}

func getJMXTargets() []string {
	if out := getCommaList("SC_JMX_TARGETS"); len(out) > 0 {
		return out
	}
	return []string{getEnv("SC_JMX_TARGET", "http://localhost:7071/metrics")}
}

// getCommaList reads a comma-separated env var into a trimmed, non-empty
// slice. Returns nil (not an error) if the var is unset — callers decide
// what an empty list means for them (e.g. Schema Registry collection is
// simply skipped if this is empty).
func getCommaList(key string) []string {
	v := os.Getenv(key)
	if v == "" {
		return nil
	}
	var out []string
	for _, t := range strings.Split(v, ",") {
		t = strings.TrimSpace(t)
		if t != "" {
			out = append(out, t)
		}
	}
	return out
}

func getEnv(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}

func getDuration(key string, fallback time.Duration) time.Duration {
	if v := os.Getenv(key); v != "" {
		if d, err := time.ParseDuration(v); err == nil {
			return d
		}
	}
	return fallback
}
