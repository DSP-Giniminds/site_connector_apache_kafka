// Package hub manages the connector's session with the control plane's
// Connector Hub: registration, heartbeat, and telemetry push.
//
// NOTE ON THIS SANDBOX BUILD: the product doc specifies gRPC streaming
// over outbound mTLS for this link. google.golang.org/grpc requires
// fetching from the Go module proxy, which isn't reachable here, so this
// is built on net/http + JSON instead — same shape of contract (register,
// heartbeat, push), swappable for a real gRPC client later without
// touching callers, since they only see the Client interface below.
package hub

import (
	"bytes"
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"time"
)

type RegisterRequest struct {
	TenantID      string `json:"tenant_id"`
	ConnectorID   string `json:"connector_id"`
	ConnectorVer  string `json:"connector_version"`
}

type HeartbeatRequest struct {
	ConnectorID string `json:"connector_id"`
	Timestamp   int64  `json:"timestamp"`
	BufferDepth int    `json:"buffer_depth"`
	Dropped     int    `json:"dropped_events"`
}

type PushRequest struct {
	ConnectorID string `json:"connector_id"`
	Kind        string `json:"kind"`
	Payload     any    `json:"payload"`
}

// Client is what the rest of the connector depends on. In a real build
// this would wrap a grpc.ClientConn with mTLS transport credentials;
// today it wraps an *http.Client. Callers don't need to know the
// difference.
type Client struct {
	baseURL     string
	connectorID string
	http        *http.Client
}

func NewClient(hubAddress, connectorID string) *Client {
	return &Client{
		baseURL:     "http://" + hubAddress, // TODO: https + mTLS transport when hardening security
		connectorID: connectorID,
		http:        &http.Client{Timeout: 5 * time.Second},
	}
}

func (c *Client) Register(tenantID string) error {
	req := RegisterRequest{TenantID: tenantID, ConnectorID: c.connectorID, ConnectorVer: "0.1.0-dev"}
	return c.post("/v1/register", req)
}

func (c *Client) Heartbeat(bufferDepth, dropped int) error {
	req := HeartbeatRequest{
		ConnectorID: c.connectorID,
		Timestamp:   time.Now().Unix(),
		BufferDepth: bufferDepth,
		Dropped:     dropped,
	}
	return c.post("/v1/heartbeat", req)
}

func (c *Client) Push(kind string, payload any) error {
	req := PushRequest{ConnectorID: c.connectorID, Kind: kind, Payload: payload}
	return c.post("/v1/push", req)
}

func (c *Client) post(path string, body any) error {
	b, err := json.Marshal(body)
	if err != nil {
		return err
	}
	resp, err := c.http.Post(c.baseURL+path, "application/json", bytes.NewReader(b))
	if err != nil {
		log.Printf("[hub] %s failed (will retry via buffer): %v", path, err)
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 300 {
		return fmt.Errorf("hub returned status %d for %s", resp.StatusCode, path)
	}
	return nil
}
