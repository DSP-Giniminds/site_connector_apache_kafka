// Package inventory runs periodic full-state reconciliation against the
// cluster — the thing that makes drift detection possible downstream
// (per the product doc, section 5.5: "periodic full inventory
// reconciliation, which is what makes drift detection possible").
package inventory

import (
	"log"
	"reflect"

	"site-connector/internal/collector"
)

type Reconciler struct {
	last *collector.Snapshot
}

func New() *Reconciler {
	return &Reconciler{}
}

// Reconcile compares the new snapshot against the last known one and
// returns whether anything changed. Real implementation would emit a
// structured diff (added/removed/modified topics, config changes, etc.)
// to the buffer for the control plane's drift-detection service; here we
// just detect and log presence of change.
func (r *Reconciler) Reconcile(snap collector.Snapshot) (changed bool) {
	if r.last == nil {
		r.last = &snap
		log.Printf("[inventory] baseline established: %d topics", len(snap.Topics))
		return true
	}
	changed = !reflect.DeepEqual(r.last.Topics, snap.Topics)
	if changed {
		log.Printf("[inventory] drift detected: topic set or config changed")
	}
	r.last = &snap
	return changed
}
