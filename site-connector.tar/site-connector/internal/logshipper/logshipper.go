// Package logshipper tails Kafka broker/controller log files and ships
// new lines to the control plane, with basic redaction applied before
// transmission (per the product doc, 5.5: log shipping is opt-in, with
// redaction applied). This is deliberately simple: a polling tail, not
// inotify-based, since portability matters more than latency here.
package logshipper

import (
	"bufio"
	"io"
	"log"
	"os"
	"regexp"
	"time"
)

// redactPatterns catches the obvious stuff: passwords, tokens, JAAS
// credentials embedded in log lines. This is a first pass, not a complete
// DLP solution — extend as real log samples surface more patterns.
var redactPatterns = []*regexp.Regexp{
	regexp.MustCompile(`(?i)(password\s*=\s*)\S+`),
	regexp.MustCompile(`(?i)(passwd\s*=\s*)\S+`),
	regexp.MustCompile(`(?i)(token\s*=\s*)\S+`),
	regexp.MustCompile(`(?i)(secret\s*=\s*)\S+`),
	regexp.MustCompile(`(?i)(api[_-]?key\s*=\s*)\S+`),
}

func redact(line string) string {
	for _, p := range redactPatterns {
		line = p.ReplaceAllString(line, "${1}[REDACTED]")
	}
	return line
}

// LogEvent is what gets pushed upstream for one new log line.
type LogEvent struct {
	Source string    // "server.log" | "controller.log"
	Line   string    // redacted content
	Time   time.Time
}

// Tailer follows a single file, polling for new content — handles the
// common case (file grows) but not log rotation edge cases yet (a
// truncated/rotated file will need re-opening logic added later).
type Tailer struct {
	path     string
	source   string
	pollFreq time.Duration
	onLine   func(LogEvent)
}

func NewTailer(path, source string, pollFreq time.Duration, onLine func(LogEvent)) *Tailer {
	return &Tailer{path: path, source: source, pollFreq: pollFreq, onLine: onLine}
}

// Run blocks, tailing the file until stopCh is closed. Starts at EOF
// (only ships new lines from the point it starts) — that's the right
// default for a long-running service; a one-time backfill would be a
// separate, explicit operation.
func (t *Tailer) Run(stopCh <-chan struct{}) {
	f, err := os.Open(t.path)
	if err != nil {
		log.Printf("[logshipper] cannot open %s: %v", t.path, err)
		return
	}
	defer f.Close()

	// seek to EOF so we only ship new lines going forward
	if _, err := f.Seek(0, io.SeekEnd); err != nil {
		log.Printf("[logshipper] seek failed on %s: %v", t.path, err)
	}

	reader := bufio.NewReader(f)
	ticker := time.NewTicker(t.pollFreq)
	defer ticker.Stop()

	for {
		select {
		case <-stopCh:
			return
		case <-ticker.C:
			for {
				line, err := reader.ReadString('\n')
				if len(line) > 0 {
					t.onLine(LogEvent{
						Source: t.source,
						Line:   redact(line),
						Time:   time.Now(),
					})
				}
				if err != nil {
					break // caught up; wait for next tick
				}
			}
		}
	}
}
